# Configuration parameters
THRESHOLD = 10000
SERVER_IP = "175.176.187.102"
SERVER_PORT = 80